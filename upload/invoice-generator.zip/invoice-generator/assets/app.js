var qrcode=function(){var t=function(t,r){var e=t,n=g[r],o=null,i=0,a=null,u=[],f={},c=function(t,r){o=function(t){for(var r=new Array(t),e=0;e<t;e+=1){r[e]=new Array(t);for(var n=0;n<t;n+=1)r[e][n]=null}return r}(i=4*e+17),l(0,0),l(i-7,0),l(0,i-7),s(),h(),d(t,r),e>=7&&v(t),null==a&&(a=p(e,n,u)),w(a,r)},l=function(t,r){for(var e=-1;e<=7;e+=1)if(!(t+e<=-1||i<=t+e))for(var n=-1;n<=7;n+=1)r+n<=-1||i<=r+n||(o[t+e][r+n]=0<=e&&e<=6&&(0==n||6==n)||0<=n&&n<=6&&(0==e||6==e)||2<=e&&e<=4&&2<=n&&n<=4)},h=function(){for(var t=8;t<i-8;t+=1)null==o[t][6]&&(o[t][6]=t%2==0);for(var r=8;r<i-8;r+=1)null==o[6][r]&&(o[6][r]=r%2==0)},s=function(){for(var t=B.getPatternPosition(e),r=0;r<t.length;r+=1)for(var n=0;n<t.length;n+=1){var i=t[r],a=t[n];if(null==o[i][a])for(var u=-2;u<=2;u+=1)for(var f=-2;f<=2;f+=1)o[i+u][a+f]=-2==u||2==u||-2==f||2==f||0==u&&0==f}},v=function(t){for(var r=B.getBCHTypeNumber(e),n=0;n<18;n+=1){var a=!t&&1==(r>>n&1);o[Math.floor(n/3)][n%3+i-8-3]=a}for(n=0;n<18;n+=1){a=!t&&1==(r>>n&1);o[n%3+i-8-3][Math.floor(n/3)]=a}},d=function(t,r){for(var e=n<<3|r,a=B.getBCHTypeInfo(e),u=0;u<15;u+=1){var f=!t&&1==(a>>u&1);u<6?o[u][8]=f:u<8?o[u+1][8]=f:o[i-15+u][8]=f}for(u=0;u<15;u+=1){f=!t&&1==(a>>u&1);u<8?o[8][i-u-1]=f:u<9?o[8][15-u-1+1]=f:o[8][15-u-1]=f}o[i-8][8]=!t},w=function(t,r){for(var e=-1,n=i-1,a=7,u=0,f=B.getMaskFunction(r),c=i-1;c>0;c-=2)for(6==c&&(c-=1);;){for(var g=0;g<2;g+=1)if(null==o[n][c-g]){var l=!1;u<t.length&&(l=1==(t[u]>>>a&1)),f(n,c-g)&&(l=!l),o[n][c-g]=l,-1==(a-=1)&&(u+=1,a=7)}if((n+=e)<0||i<=n){n-=e,e=-e;break}}},p=function(t,r,e){for(var n=A.getRSBlocks(t,r),o=b(),i=0;i<e.length;i+=1){var a=e[i];o.put(a.getMode(),4),o.put(a.getLength(),B.getLengthInBits(a.getMode(),t)),a.write(o)}var u=0;for(i=0;i<n.length;i+=1)u+=n[i].dataCount;if(o.getLengthInBits()>8*u)throw"code length overflow. ("+o.getLengthInBits()+">"+8*u+")";for(o.getLengthInBits()+4<=8*u&&o.put(0,4);o.getLengthInBits()%8!=0;)o.putBit(!1);for(;!(o.getLengthInBits()>=8*u||(o.put(236,8),o.getLengthInBits()>=8*u));)o.put(17,8);return function(t,r){for(var e=0,n=0,o=0,i=new Array(r.length),a=new Array(r.length),u=0;u<r.length;u+=1){var f=r[u].dataCount,c=r[u].totalCount-f;n=Math.max(n,f),o=Math.max(o,c),i[u]=new Array(f);for(var g=0;g<i[u].length;g+=1)i[u][g]=255&t.getBuffer()[g+e];e+=f;var l=B.getErrorCorrectPolynomial(c),h=k(i[u],l.getLength()-1).mod(l);for(a[u]=new Array(l.getLength()-1),g=0;g<a[u].length;g+=1){var s=g+h.getLength()-a[u].length;a[u][g]=s>=0?h.getAt(s):0}}var v=0;for(g=0;g<r.length;g+=1)v+=r[g].totalCount;var d=new Array(v),w=0;for(g=0;g<n;g+=1)for(u=0;u<r.length;u+=1)g<i[u].length&&(d[w]=i[u][g],w+=1);for(g=0;g<o;g+=1)for(u=0;u<r.length;u+=1)g<a[u].length&&(d[w]=a[u][g],w+=1);return d}(o,n)};f.addData=function(t,r){var e=null;switch(r=r||"Byte"){case"Numeric":e=M(t);break;case"Alphanumeric":e=x(t);break;case"Byte":e=m(t);break;case"Kanji":e=L(t);break;default:throw"mode:"+r}u.push(e),a=null},f.isDark=function(t,r){if(t<0||i<=t||r<0||i<=r)throw t+","+r;return o[t][r]},f.getModuleCount=function(){return i},f.make=function(){if(e<1){for(var t=1;t<40;t++){for(var r=A.getRSBlocks(t,n),o=b(),i=0;i<u.length;i++){var a=u[i];o.put(a.getMode(),4),o.put(a.getLength(),B.getLengthInBits(a.getMode(),t)),a.write(o)}var g=0;for(i=0;i<r.length;i++)g+=r[i].dataCount;if(o.getLengthInBits()<=8*g)break}e=t}c(!1,function(){for(var t=0,r=0,e=0;e<8;e+=1){c(!0,e);var n=B.getLostPoint(f);(0==e||t>n)&&(t=n,r=e)}return r}())},f.createTableTag=function(t,r){t=t||2;var e="";e+='<table style="',e+=" border-width: 0px; border-style: none;",e+=" border-collapse: collapse;",e+=" padding: 0px; margin: "+(r=void 0===r?4*t:r)+"px;",e+='">',e+="<tbody>";for(var n=0;n<f.getModuleCount();n+=1){e+="<tr>";for(var o=0;o<f.getModuleCount();o+=1)e+='<td style="',e+=" border-width: 0px; border-style: none;",e+=" border-collapse: collapse;",e+=" padding: 0px; margin: 0px;",e+=" width: "+t+"px;",e+=" height: "+t+"px;",e+=" background-color: ",e+=f.isDark(n,o)?"#000000":"#ffffff",e+=";",e+='"/>';e+="</tr>"}return e+="</tbody>",e+="</table>"},f.createSvgTag=function(t,r,e,n){var o={};"object"==typeof arguments[0]&&(t=(o=arguments[0]).cellSize,r=o.margin,e=o.alt,n=o.title),t=t||2,r=void 0===r?4*t:r,(e="string"==typeof e?{text:e}:e||{}).text=e.text||null,e.id=e.text?e.id||"qrcode-description":null,(n="string"==typeof n?{text:n}:n||{}).text=n.text||null,n.id=n.text?n.id||"qrcode-title":null;var i,a,u,c,g=f.getModuleCount()*t+2*r,l="";for(c="l"+t+",0 0,"+t+" -"+t+",0 0,-"+t+"z ",l+='<svg version="1.1" xmlns="http://www.w3.org/2000/svg"',l+=o.scalable?"":' width="'+g+'px" height="'+g+'px"',l+=' viewBox="0 0 '+g+" "+g+'" ',l+=' preserveAspectRatio="xMinYMin meet"',l+=n.text||e.text?' role="img" aria-labelledby="'+y([n.id,e.id].join(" ").trim())+'"':"",l+=">",l+=n.text?'<title id="'+y(n.id)+'">'+y(n.text)+"</title>":"",l+=e.text?'<description id="'+y(e.id)+'">'+y(e.text)+"</description>":"",l+='<rect width="100%" height="100%" fill="white" cx="0" cy="0"/>',l+='<path d="',a=0;a<f.getModuleCount();a+=1)for(u=a*t+r,i=0;i<f.getModuleCount();i+=1)f.isDark(a,i)&&(l+="M"+(i*t+r)+","+u+c);return l+='" stroke="transparent" fill="black"/>',l+="</svg>"},f.createDataURL=function(t,r){t=t||2,r=void 0===r?4*t:r;var e=f.getModuleCount()*t+2*r,n=r,o=e-r;return I(e,e,function(r,e){if(n<=r&&r<o&&n<=e&&e<o){var i=Math.floor((r-n)/t),a=Math.floor((e-n)/t);return f.isDark(a,i)?0:1}return 1})},f.createImgTag=function(t,r,e){t=t||2,r=void 0===r?4*t:r;var n=f.getModuleCount()*t+2*r,o="";return o+="<img",o+=' src="',o+=f.createDataURL(t,r),o+='"',o+=' width="',o+=n,o+='"',o+=' height="',o+=n,o+='"',e&&(o+=' alt="',o+=y(e),o+='"'),o+="/>"};var y=function(t){for(var r="",e=0;e<t.length;e+=1){var n=t.charAt(e);switch(n){case"<":r+="&lt;";break;case">":r+="&gt;";break;case"&":r+="&amp;";break;case'"':r+="&quot;";break;default:r+=n}}return r};return f.createASCII=function(t,r){if((t=t||1)<2)return function(t){t=void 0===t?2:t;var r,e,n,o,i,a=1*f.getModuleCount()+2*t,u=t,c=a-t,g={"██":"█","█ ":"▀"," █":"▄","  ":" "},l={"██":"▀","█ ":"▀"," █":" ","  ":" "},h="";for(r=0;r<a;r+=2){for(n=Math.floor((r-u)/1),o=Math.floor((r+1-u)/1),e=0;e<a;e+=1)i="█",u<=e&&e<c&&u<=r&&r<c&&f.isDark(n,Math.floor((e-u)/1))&&(i=" "),u<=e&&e<c&&u<=r+1&&r+1<c&&f.isDark(o,Math.floor((e-u)/1))?i+=" ":i+="█",h+=t<1&&r+1>=c?l[i]:g[i];h+="\n"}return a%2&&t>0?h.substring(0,h.length-a-1)+Array(a+1).join("▀"):h.substring(0,h.length-1)}(r);t-=1,r=void 0===r?2*t:r;var e,n,o,i,a=f.getModuleCount()*t+2*r,u=r,c=a-r,g=Array(t+1).join("██"),l=Array(t+1).join("  "),h="",s="";for(e=0;e<a;e+=1){for(o=Math.floor((e-u)/t),s="",n=0;n<a;n+=1)i=1,u<=n&&n<c&&u<=e&&e<c&&f.isDark(o,Math.floor((n-u)/t))&&(i=0),s+=i?g:l;for(o=0;o<t;o+=1)h+=s+"\n"}return h.substring(0,h.length-1)},f.renderTo2dContext=function(t,r){r=r||2;for(var e=f.getModuleCount(),n=0;n<e;n++)for(var o=0;o<e;o++)t.fillStyle=f.isDark(n,o)?"black":"white",t.fillRect(o*r,n*r,r,r)},f};t.stringToBytes=(t.stringToBytesFuncs={default:function(t){for(var r=[],e=0;e<t.length;e+=1){var n=t.charCodeAt(e);r.push(255&n)}return r}}).default,t.createStringToBytes=function(t,r){var e=function(){for(var e=S(t),n=function(){var t=e.read();if(-1==t)throw"eof";return t},o=0,i={};;){var a=e.read();if(-1==a)break;var u=n(),f=n()<<8|n();i[String.fromCharCode(a<<8|u)]=f,o+=1}if(o!=r)throw o+" != "+r;return i}(),n="?".charCodeAt(0);return function(t){for(var r=[],o=0;o<t.length;o+=1){var i=t.charCodeAt(o);if(i<128)r.push(i);else{var a=e[t.charAt(o)];"number"==typeof a?(255&a)==a?r.push(a):(r.push(a>>>8),r.push(255&a)):r.push(n)}}return r}};var r,e,n,o,i,a=1,u=2,f=4,c=8,g={L:1,M:0,Q:3,H:2},l=0,h=1,s=2,v=3,d=4,w=5,p=6,y=7,B=(r=[[],[6,18],[6,22],[6,26],[6,30],[6,34],[6,22,38],[6,24,42],[6,26,46],[6,28,50],[6,30,54],[6,32,58],[6,34,62],[6,26,46,66],[6,26,48,70],[6,26,50,74],[6,30,54,78],[6,30,56,82],[6,30,58,86],[6,34,62,90],[6,28,50,72,94],[6,26,50,74,98],[6,30,54,78,102],[6,28,54,80,106],[6,32,58,84,110],[6,30,58,86,114],[6,34,62,90,118],[6,26,50,74,98,122],[6,30,54,78,102,126],[6,26,52,78,104,130],[6,30,56,82,108,134],[6,34,60,86,112,138],[6,30,58,86,114,142],[6,34,62,90,118,146],[6,30,54,78,102,126,150],[6,24,50,76,102,128,154],[6,28,54,80,106,132,158],[6,32,58,84,110,136,162],[6,26,54,82,110,138,166],[6,30,58,86,114,142,170]],e=1335,n=7973,i=function(t){for(var r=0;0!=t;)r+=1,t>>>=1;return r},(o={}).getBCHTypeInfo=function(t){for(var r=t<<10;i(r)-i(e)>=0;)r^=e<<i(r)-i(e);return 21522^(t<<10|r)},o.getBCHTypeNumber=function(t){for(var r=t<<12;i(r)-i(n)>=0;)r^=n<<i(r)-i(n);return t<<12|r},o.getPatternPosition=function(t){return r[t-1]},o.getMaskFunction=function(t){switch(t){case l:return function(t,r){return(t+r)%2==0};case h:return function(t,r){return t%2==0};case s:return function(t,r){return r%3==0};case v:return function(t,r){return(t+r)%3==0};case d:return function(t,r){return(Math.floor(t/2)+Math.floor(r/3))%2==0};case w:return function(t,r){return t*r%2+t*r%3==0};case p:return function(t,r){return(t*r%2+t*r%3)%2==0};case y:return function(t,r){return(t*r%3+(t+r)%2)%2==0};default:throw"bad maskPattern:"+t}},o.getErrorCorrectPolynomial=function(t){for(var r=k([1],0),e=0;e<t;e+=1)r=r.multiply(k([1,C.gexp(e)],0));return r},o.getLengthInBits=function(t,r){if(1<=r&&r<10)switch(t){case a:return 10;case u:return 9;case f:case c:return 8;default:throw"mode:"+t}else if(r<27)switch(t){case a:return 12;case u:return 11;case f:return 16;case c:return 10;default:throw"mode:"+t}else{if(!(r<41))throw"type:"+r;switch(t){case a:return 14;case u:return 13;case f:return 16;case c:return 12;default:throw"mode:"+t}}},o.getLostPoint=function(t){for(var r=t.getModuleCount(),e=0,n=0;n<r;n+=1)for(var o=0;o<r;o+=1){for(var i=0,a=t.isDark(n,o),u=-1;u<=1;u+=1)if(!(n+u<0||r<=n+u))for(var f=-1;f<=1;f+=1)o+f<0||r<=o+f||0==u&&0==f||a==t.isDark(n+u,o+f)&&(i+=1);i>5&&(e+=3+i-5)}for(n=0;n<r-1;n+=1)for(o=0;o<r-1;o+=1){var c=0;t.isDark(n,o)&&(c+=1),t.isDark(n+1,o)&&(c+=1),t.isDark(n,o+1)&&(c+=1),t.isDark(n+1,o+1)&&(c+=1),0!=c&&4!=c||(e+=3)}for(n=0;n<r;n+=1)for(o=0;o<r-6;o+=1)t.isDark(n,o)&&!t.isDark(n,o+1)&&t.isDark(n,o+2)&&t.isDark(n,o+3)&&t.isDark(n,o+4)&&!t.isDark(n,o+5)&&t.isDark(n,o+6)&&(e+=40);for(o=0;o<r;o+=1)for(n=0;n<r-6;n+=1)t.isDark(n,o)&&!t.isDark(n+1,o)&&t.isDark(n+2,o)&&t.isDark(n+3,o)&&t.isDark(n+4,o)&&!t.isDark(n+5,o)&&t.isDark(n+6,o)&&(e+=40);var g=0;for(o=0;o<r;o+=1)for(n=0;n<r;n+=1)t.isDark(n,o)&&(g+=1);return e+=Math.abs(100*g/r/r-50)/5*10},o),C=function(){for(var t=new Array(256),r=new Array(256),e=0;e<8;e+=1)t[e]=1<<e;for(e=8;e<256;e+=1)t[e]=t[e-4]^t[e-5]^t[e-6]^t[e-8];for(e=0;e<255;e+=1)r[t[e]]=e;var n={glog:function(t){if(t<1)throw"glog("+t+")";return r[t]},gexp:function(r){for(;r<0;)r+=255;for(;r>=256;)r-=255;return t[r]}};return n}();function k(t,r){if(void 0===t.length)throw t.length+"/"+r;var e=function(){for(var e=0;e<t.length&&0==t[e];)e+=1;for(var n=new Array(t.length-e+r),o=0;o<t.length-e;o+=1)n[o]=t[o+e];return n}(),n={getAt:function(t){return e[t]},getLength:function(){return e.length},multiply:function(t){for(var r=new Array(n.getLength()+t.getLength()-1),e=0;e<n.getLength();e+=1)for(var o=0;o<t.getLength();o+=1)r[e+o]^=C.gexp(C.glog(n.getAt(e))+C.glog(t.getAt(o)));return k(r,0)},mod:function(t){if(n.getLength()-t.getLength()<0)return n;for(var r=C.glog(n.getAt(0))-C.glog(t.getAt(0)),e=new Array(n.getLength()),o=0;o<n.getLength();o+=1)e[o]=n.getAt(o);for(o=0;o<t.getLength();o+=1)e[o]^=C.gexp(C.glog(t.getAt(o))+r);return k(e,0).mod(t)}};return n}var A=function(){var t=[[1,26,19],[1,26,16],[1,26,13],[1,26,9],[1,44,34],[1,44,28],[1,44,22],[1,44,16],[1,70,55],[1,70,44],[2,35,17],[2,35,13],[1,100,80],[2,50,32],[2,50,24],[4,25,9],[1,134,108],[2,67,43],[2,33,15,2,34,16],[2,33,11,2,34,12],[2,86,68],[4,43,27],[4,43,19],[4,43,15],[2,98,78],[4,49,31],[2,32,14,4,33,15],[4,39,13,1,40,14],[2,121,97],[2,60,38,2,61,39],[4,40,18,2,41,19],[4,40,14,2,41,15],[2,146,116],[3,58,36,2,59,37],[4,36,16,4,37,17],[4,36,12,4,37,13],[2,86,68,2,87,69],[4,69,43,1,70,44],[6,43,19,2,44,20],[6,43,15,2,44,16],[4,101,81],[1,80,50,4,81,51],[4,50,22,4,51,23],[3,36,12,8,37,13],[2,116,92,2,117,93],[6,58,36,2,59,37],[4,46,20,6,47,21],[7,42,14,4,43,15],[4,133,107],[8,59,37,1,60,38],[8,44,20,4,45,21],[12,33,11,4,34,12],[3,145,115,1,146,116],[4,64,40,5,65,41],[11,36,16,5,37,17],[11,36,12,5,37,13],[5,109,87,1,110,88],[5,65,41,5,66,42],[5,54,24,7,55,25],[11,36,12,7,37,13],[5,122,98,1,123,99],[7,73,45,3,74,46],[15,43,19,2,44,20],[3,45,15,13,46,16],[1,135,107,5,136,108],[10,74,46,1,75,47],[1,50,22,15,51,23],[2,42,14,17,43,15],[5,150,120,1,151,121],[9,69,43,4,70,44],[17,50,22,1,51,23],[2,42,14,19,43,15],[3,141,113,4,142,114],[3,70,44,11,71,45],[17,47,21,4,48,22],[9,39,13,16,40,14],[3,135,107,5,136,108],[3,67,41,13,68,42],[15,54,24,5,55,25],[15,43,15,10,44,16],[4,144,116,4,145,117],[17,68,42],[17,50,22,6,51,23],[19,46,16,6,47,17],[2,139,111,7,140,112],[17,74,46],[7,54,24,16,55,25],[34,37,13],[4,151,121,5,152,122],[4,75,47,14,76,48],[11,54,24,14,55,25],[16,45,15,14,46,16],[6,147,117,4,148,118],[6,73,45,14,74,46],[11,54,24,16,55,25],[30,46,16,2,47,17],[8,132,106,4,133,107],[8,75,47,13,76,48],[7,54,24,22,55,25],[22,45,15,13,46,16],[10,142,114,2,143,115],[19,74,46,4,75,47],[28,50,22,6,51,23],[33,46,16,4,47,17],[8,152,122,4,153,123],[22,73,45,3,74,46],[8,53,23,26,54,24],[12,45,15,28,46,16],[3,147,117,10,148,118],[3,73,45,23,74,46],[4,54,24,31,55,25],[11,45,15,31,46,16],[7,146,116,7,147,117],[21,73,45,7,74,46],[1,53,23,37,54,24],[19,45,15,26,46,16],[5,145,115,10,146,116],[19,75,47,10,76,48],[15,54,24,25,55,25],[23,45,15,25,46,16],[13,145,115,3,146,116],[2,74,46,29,75,47],[42,54,24,1,55,25],[23,45,15,28,46,16],[17,145,115],[10,74,46,23,75,47],[10,54,24,35,55,25],[19,45,15,35,46,16],[17,145,115,1,146,116],[14,74,46,21,75,47],[29,54,24,19,55,25],[11,45,15,46,46,16],[13,145,115,6,146,116],[14,74,46,23,75,47],[44,54,24,7,55,25],[59,46,16,1,47,17],[12,151,121,7,152,122],[12,75,47,26,76,48],[39,54,24,14,55,25],[22,45,15,41,46,16],[6,151,121,14,152,122],[6,75,47,34,76,48],[46,54,24,10,55,25],[2,45,15,64,46,16],[17,152,122,4,153,123],[29,74,46,14,75,47],[49,54,24,10,55,25],[24,45,15,46,46,16],[4,152,122,18,153,123],[13,74,46,32,75,47],[48,54,24,14,55,25],[42,45,15,32,46,16],[20,147,117,4,148,118],[40,75,47,7,76,48],[43,54,24,22,55,25],[10,45,15,67,46,16],[19,148,118,6,149,119],[18,75,47,31,76,48],[34,54,24,34,55,25],[20,45,15,61,46,16]],r=function(t,r){var e={};return e.totalCount=t,e.dataCount=r,e},e={};return e.getRSBlocks=function(e,n){var o=function(r,e){switch(e){case g.L:return t[4*(r-1)+0];case g.M:return t[4*(r-1)+1];case g.Q:return t[4*(r-1)+2];case g.H:return t[4*(r-1)+3];default:return}}(e,n);if(void 0===o)throw"bad rs block @ typeNumber:"+e+"/errorCorrectionLevel:"+n;for(var i=o.length/3,a=[],u=0;u<i;u+=1)for(var f=o[3*u+0],c=o[3*u+1],l=o[3*u+2],h=0;h<f;h+=1)a.push(r(c,l));return a},e}(),b=function(){var t=[],r=0,e={getBuffer:function(){return t},getAt:function(r){var e=Math.floor(r/8);return 1==(t[e]>>>7-r%8&1)},put:function(t,r){for(var n=0;n<r;n+=1)e.putBit(1==(t>>>r-n-1&1))},getLengthInBits:function(){return r},putBit:function(e){var n=Math.floor(r/8);t.length<=n&&t.push(0),e&&(t[n]|=128>>>r%8),r+=1}};return e},M=function(t){var r=a,e=t,n={getMode:function(){return r},getLength:function(t){return e.length},write:function(t){for(var r=e,n=0;n+2<r.length;)t.put(o(r.substring(n,n+3)),10),n+=3;n<r.length&&(r.length-n==1?t.put(o(r.substring(n,n+1)),4):r.length-n==2&&t.put(o(r.substring(n,n+2)),7))}},o=function(t){for(var r=0,e=0;e<t.length;e+=1)r=10*r+i(t.charAt(e));return r},i=function(t){if("0"<=t&&t<="9")return t.charCodeAt(0)-"0".charCodeAt(0);throw"illegal char :"+t};return n},x=function(t){var r=u,e=t,n={getMode:function(){return r},getLength:function(t){return e.length},write:function(t){for(var r=e,n=0;n+1<r.length;)t.put(45*o(r.charAt(n))+o(r.charAt(n+1)),11),n+=2;n<r.length&&t.put(o(r.charAt(n)),6)}},o=function(t){if("0"<=t&&t<="9")return t.charCodeAt(0)-"0".charCodeAt(0);if("A"<=t&&t<="Z")return t.charCodeAt(0)-"A".charCodeAt(0)+10;switch(t){case" ":return 36;case"$":return 37;case"%":return 38;case"*":return 39;case"+":return 40;case"-":return 41;case".":return 42;case"/":return 43;case":":return 44;default:throw"illegal char :"+t}};return n},m=function(r){var e=f,n=t.stringToBytes(r),o={getMode:function(){return e},getLength:function(t){return n.length},write:function(t){for(var r=0;r<n.length;r+=1)t.put(n[r],8)}};return o},L=function(r){var e=c,n=t.stringToBytesFuncs.SJIS;if(!n)throw"sjis not supported.";!function(){var t=n("友");if(2!=t.length||38726!=(t[0]<<8|t[1]))throw"sjis not supported."}();var o=n(r),i={getMode:function(){return e},getLength:function(t){return~~(o.length/2)},write:function(t){for(var r=o,e=0;e+1<r.length;){var n=(255&r[e])<<8|255&r[e+1];if(33088<=n&&n<=40956)n-=33088;else{if(!(57408<=n&&n<=60351))throw"illegal char at "+(e+1)+"/"+n;n-=49472}n=192*(n>>>8&255)+(255&n),t.put(n,13),e+=2}if(e<r.length)throw"illegal char at "+(e+1)}};return i},D=function(){var t=[],r={writeByte:function(r){t.push(255&r)},writeShort:function(t){r.writeByte(t),r.writeByte(t>>>8)},writeBytes:function(t,e,n){e=e||0,n=n||t.length;for(var o=0;o<n;o+=1)r.writeByte(t[o+e])},writeString:function(t){for(var e=0;e<t.length;e+=1)r.writeByte(t.charCodeAt(e))},toByteArray:function(){return t},toString:function(){var r="";r+="[";for(var e=0;e<t.length;e+=1)e>0&&(r+=","),r+=t[e];return r+="]"}};return r},S=function(t){var r=t,e=0,n=0,o=0,i={read:function(){for(;o<8;){if(e>=r.length){if(0==o)return-1;throw"unexpected end of file./"+o}var t=r.charAt(e);if(e+=1,"="==t)return o=0,-1;t.match(/^\s$/)||(n=n<<6|a(t.charCodeAt(0)),o+=6)}var i=n>>>o-8&255;return o-=8,i}},a=function(t){if(65<=t&&t<=90)return t-65;if(97<=t&&t<=122)return t-97+26;if(48<=t&&t<=57)return t-48+52;if(43==t)return 62;if(47==t)return 63;throw"c:"+t};return i},I=function(t,r,e){for(var n=function(t,r){var e=t,n=r,o=new Array(t*r),i={setPixel:function(t,r,n){o[r*e+t]=n},write:function(t){t.writeString("GIF87a"),t.writeShort(e),t.writeShort(n),t.writeByte(128),t.writeByte(0),t.writeByte(0),t.writeByte(0),t.writeByte(0),t.writeByte(0),t.writeByte(255),t.writeByte(255),t.writeByte(255),t.writeString(","),t.writeShort(0),t.writeShort(0),t.writeShort(e),t.writeShort(n),t.writeByte(0);var r=a(2);t.writeByte(2);for(var o=0;r.length-o>255;)t.writeByte(255),t.writeBytes(r,o,255),o+=255;t.writeByte(r.length-o),t.writeBytes(r,o,r.length-o),t.writeByte(0),t.writeString(";")}},a=function(t){for(var r=1<<t,e=1+(1<<t),n=t+1,i=u(),a=0;a<r;a+=1)i.add(String.fromCharCode(a));i.add(String.fromCharCode(r)),i.add(String.fromCharCode(e));var f,c,g,l=D(),h=(f=l,c=0,g=0,{write:function(t,r){if(t>>>r!=0)throw"length over";for(;c+r>=8;)f.writeByte(255&(t<<c|g)),r-=8-c,t>>>=8-c,g=0,c=0;g|=t<<c,c+=r},flush:function(){c>0&&f.writeByte(g)}});h.write(r,n);var s=0,v=String.fromCharCode(o[s]);for(s+=1;s<o.length;){var d=String.fromCharCode(o[s]);s+=1,i.contains(v+d)?v+=d:(h.write(i.indexOf(v),n),i.size()<4095&&(i.size()==1<<n&&(n+=1),i.add(v+d)),v=d)}return h.write(i.indexOf(v),n),h.write(e,n),h.flush(),l.toByteArray()},u=function(){var t={},r=0,e={add:function(n){if(e.contains(n))throw"dup key:"+n;t[n]=r,r+=1},size:function(){return r},indexOf:function(r){return t[r]},contains:function(r){return void 0!==t[r]}};return e};return i}(t,r),o=0;o<r;o+=1)for(var i=0;i<t;i+=1)n.setPixel(i,o,e(i,o));var a=D();n.write(a);for(var u=function(){var t=0,r=0,e=0,n="",o={},i=function(t){n+=String.fromCharCode(a(63&t))},a=function(t){if(t<0);else{if(t<26)return 65+t;if(t<52)return t-26+97;if(t<62)return t-52+48;if(62==t)return 43;if(63==t)return 47}throw"n:"+t};return o.writeByte=function(n){for(t=t<<8|255&n,r+=8,e+=1;r>=6;)i(t>>>r-6),r-=6},o.flush=function(){if(r>0&&(i(t<<6-r),t=0,r=0),e%3!=0)for(var o=3-e%3,a=0;a<o;a+=1)n+="="},o.toString=function(){return n},o}(),f=a.toByteArray(),c=0;c<f.length;c+=1)u.writeByte(f[c]);return u.flush(),"data:image/gif;base64,"+u};return t}();qrcode.stringToBytesFuncs["UTF-8"]=function(t){return function(t){for(var r=[],e=0;e<t.length;e++){var n=t.charCodeAt(e);n<128?r.push(n):n<2048?r.push(192|n>>6,128|63&n):n<55296||n>=57344?r.push(224|n>>12,128|n>>6&63,128|63&n):(e++,n=65536+((1023&n)<<10|1023&t.charCodeAt(e)),r.push(240|n>>18,128|n>>12&63,128|n>>6&63,128|63&n))}return r}(t)},function(t){"function"==typeof define&&define.amd?define([],t):"object"==typeof exports&&(module.exports=t())}(function(){return qrcode});

/*CORE*/
const R=x=>Math.round(+x.toFixed(6)),P=v=>R((parseFloat(v)||0)*100);
const ON='|One|Two|Three|Four|Five|Six|Seven|Eight|Nine|Ten|Eleven|Twelve|Thirteen|Fourteen|Fifteen|Sixteen|Seventeen|Eighteen|Nineteen'.split('|'),TN='||Twenty|Thirty|Forty|Fifty|Sixty|Seventy|Eighty|Ninety'.split('|');
const w2=n=>n<20?ON[n]:TN[n/10|0]+(n%10?' '+ON[n%10]:'');
const w3=n=>(n>99?ON[n/100|0]+' Hundred'+(n%100?' ':''):'')+(n%100?w2(n%100):'');
const CN={INR:['Rupees','Paise'],USD:['Dollars','Cents'],EUR:['Euros','Cents'],GBP:['Pounds','Pence']};
function words(p,cur){let n=Math.floor(p/100),c=p%100,o=[];
 for(const[v,s]of cur==='INR'?[[1e7,'Crore'],[1e5,'Lakh'],[1e3,'Thousand']]:[[1e9,'Billion'],[1e6,'Million'],[1e3,'Thousand']])if(n>=v){o.push(w3(Math.floor(n/v))+' '+s);n%=v}
 if(n||!o.length)o.push(n?w3(n):'Zero');
 return CN[cur][0]+' '+o.join(' ')+(c?' and '+w2(c)+' '+CN[cur][1]:'')+' Only'}
const AL='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const gstOK=g=>{if(!/^\d{2}[A-Z]{5}\d{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/.test(g))return false;let s=0;for(let i=0;i<14;i++){const v=AL.indexOf(g[i])*(i%2?2:1);s+=Math.floor(v/36)+v%36}return AL[(36-s%36)%36]===g[14]};
const bump=s=>s&&/\d/.test(s)?s.replace(/(\d+)(?!.*\d)/,m=>String(+m+1).padStart(m.length,'0')):'INV-001';
function calc(){
 const g=S.tpl==='gst',L=S.items.map(i=>({...i,amt:R((parseFloat(i.q)||0)*P(i.r))})),sub=L.reduce((a,l)=>a+l.amt,0),dv=parseFloat(S.d)||0,
 disc=Math.max(0,Math.min(sub,S.dt==='%'?R(sub*Math.min(dv,100)/100):P(dv))),intra=!S.biz.state||!S.pos||S.biz.state===S.pos;
 let rem=disc,tb=0,cg=0,sg=0,ig=0,tx=0;
 L.forEach((l,k)=>{const sh=k===L.length-1?rem:R(disc*l.amt/(sub||1));rem-=sh;l.tb=l.amt-sh;
  const rt=S.nt?0:g?parseFloat(l.g)||0:parseFloat(S.tr)||0;l.rt=rt;l.cg=l.sg=l.ig=l.t=0;
  if(!g)l.t=R(l.tb*rt/100);else if(intra)l.cg=l.sg=R(l.tb*rt/200);else l.ig=R(l.tb*rt/100);
  tb+=l.tb;cg+=l.cg;sg+=l.sg;ig+=l.ig;tx+=l.t});
 const gr=tb+cg+sg+ig+tx,tot=S.ro?R(gr/100)*100:gr;
 return{L,g,sub,disc,tb,cg,sg,ig,tx,ro:tot-gr,tot,intra}}
/*END*/
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const br=s=>esc(s).replace(/\n/g,'<br>');
const ST='01 Jammu & Kashmir|02 Himachal Pradesh|03 Punjab|04 Chandigarh|05 Uttarakhand|06 Haryana|07 Delhi|08 Rajasthan|09 Uttar Pradesh|10 Bihar|11 Sikkim|12 Arunachal Pradesh|13 Nagaland|14 Manipur|15 Mizoram|16 Tripura|17 Meghalaya|18 Assam|19 West Bengal|20 Jharkhand|21 Odisha|22 Chhattisgarh|23 Madhya Pradesh|24 Gujarat|25 Daman & Diu (old code)|26 Dadra & Nagar Haveli and Daman & Diu|27 Maharashtra|28 Andhra Pradesh (old code)|29 Karnataka|30 Goa|31 Lakshadweep|32 Kerala|33 Tamil Nadu|34 Puducherry|35 Andaman & Nicobar Islands|36 Telangana|37 Andhra Pradesh|38 Ladakh|97 Other Territory'.split('|');
const T={en:{},hi:{}};
`h1|Invoice Generator|इनवॉइस जनरेटर
priv|100% private: your data never leaves this browser|100% प्राइवेट: आपका डेटा इसी ब्राउज़र में रहता है
t1|Standard / Service|स्टैंडर्ड / सर्विस
t2|GST Invoice|GST इनवॉइस
t3|Hourly / Freelance|घंटे / फ्रीलांस
t4|Proforma / Quotation|प्रोफ़ॉर्मा / कोटेशन
yb|Your business|आपका व्यवसाय
bn|Business name|व्यवसाय का नाम
addr|Address|पता
state|State|राज्य
ph|Phone|फ़ोन
em|Email|ईमेल
bank|Bank details|बैंक विवरण
logo|Logo|लोगो
rm|Remove logo|लोगो हटाएं
bt|Bill to|बिल प्राप्तकर्ता
cn|Client name|ग्राहक का नाम
pos|Place of supply|आपूर्ति का स्थान
intra|Same state: CGST + SGST|समान राज्य: CGST + SGST
inter|Different state: IGST|अलग राज्य: IGST
pick|Select your state and place of supply to confirm CGST + SGST or IGST|CGST + SGST या IGST तय करने के लिए अपना राज्य और आपूर्ति का स्थान चुनें
gerr|GSTIN looks invalid|GSTIN सही नहीं लग रहा
det|Invoice details|इनवॉइस विवरण
no|Invoice no.|इनवॉइस नं.
cur|Currency|मुद्रा
date|Date|दिनांक
due|Due date|देय तिथि
valid|Valid until|मान्य तिथि तक
dtype|Document|दस्तावेज़
itm|Items|आइटम
add|+ Add item|+ आइटम जोड़ें
desc|Description|विवरण
task|Task|कार्य
hsn|HSN / SAC|HSN / SAC
qty|Qty|मात्रा
hrs|Hours|घंटे
rate|Rate|दर
rhr|Rate / hr|दर / घंटा
disc|Discount (before tax)|छूट (कर से पहले)
flat|Flat amount|सीधी राशि
trate|Tax %|कर %
ro|Round off total to whole number|कुल राशि पूर्ण संख्या में राउंड ऑफ़ करें
notes|Notes|टिप्पणी
terms|Terms|नियम व शर्तें
pdf|Save as PDF|PDF सेव करें
print|Print|प्रिंट
new|New invoice|नया इनवॉइस
dz|Design: drag blocks|डिज़ाइन: ब्लॉक खींचें
ty|Invoice type|इनवॉइस का प्रकार
adv|Advance / amount received|एडवांस / प्राप्त राशि
bal|Balance due|बकाया राशि
st|Payment status|भुगतान स्थिति
sgi|Signature image|हस्ताक्षर की छवि
sv|Save|सेव
open|My saved invoices|मेरे सेव किए इनवॉइस
wno|Invoice no. must be 1-16 characters: letters, numbers, - or /|इनवॉइस नं. 1-16 अक्षरों का हो: अक्षर, अंक, - या /
wh|HSN/SAC should be 4, 6 or 8 digits. Check item|HSN/SAC 4, 6 या 8 अंकों का हो। आइटम जांचें
wr|Unusual GST rate. Check item|असामान्य GST दर। आइटम जांचें
wst|GSTIN state code does not match your state|GSTIN का राज्य कोड आपके राज्य से मेल नहीं खाता
wew|Moving goods worth over ₹50,000? An e-way bill is needed before dispatch|₹50,000 से ज़्यादा का माल भेज रहे हैं? डिस्पैच से पहले ई-वे बिल ज़रूरी है
days|Days
rday|Rate / day
sqft|Sq ft
rsqft|Rate / sq ft
km|Km
rkm|Rate / km
night|Nights
rnight|Rate / night
mth|Months
rmth|Rate / month
inv|Invoice|इनवॉइस
taxinv|Tax Invoice|टैक्स इनवॉइस
pro|Proforma Invoice|प्रोफ़ॉर्मा इनवॉइस
quo|Quotation|कोटेशन
tb|Taxable value|कर योग्य मूल्य
gp|GST %|GST %
amt|Amount|राशि
sub|Subtotal|उप-योग
disc2|Discount|छूट
cg|CGST|CGST
sg|SGST|SGST
ig|IGST|IGST
tx|Tax|कर
rof|Round off|राउंड ऑफ़
tot|Total|कुल योग
wd|Amount in words|राशि शब्दों में
for|For|कृते
sig|Authorised signatory|अधिकृत हस्ताक्षरकर्ता`.split('\n').forEach(l=>{const[k,e,h]=l.split('|');T.en[k]=e;T.hi[k]=h});
const t=k=>T[S.lang][k]||T.en[k]||k;
const LS=(()=>{try{return JSON.parse(localStorage.getItem('dp_inv')||'{}')}catch(e){return{}}})();
const save=()=>{try{localStorage.setItem('dp_inv',JSON.stringify({biz:S.biz,lang:S.lang,cur:S.cur,terms:S.terms,tu:S.tu,ty:S.ty,l:LS.l,ord:S.ord,ac:S.ac}))}catch(e){}};
const today=()=>new Date(Date.now()-new Date().getTimezoneOffset()*6e4).toISOString().slice(0,10);
const plus=n=>{const x=new Date();x.setDate(x.getDate()+n);return new Date(x-x.getTimezoneOffset()*6e4).toISOString().slice(0,10)};
const fd=d=>d?d.split('-').reverse().join('/'):'';
const blank=()=>({d:'',h:'',q:1,r:'',g:S.items&&S.items.length?S.items[S.items.length-1].g:18});
const S={tpl:'gst',lang:LS.lang||'en',cur:LS.cur||'INR',biz:{name:'',addr:'',gstin:'',state:'',phone:'',email:'',bank:'',upi:'',logo:'',...LS.biz},
 cli:{name:'',addr:'',gstin:'',state:''},pos:'',no:'',date:today(),due:plus(15),valid:plus(15),dt:'%',d:'',tr:'',ro:true,pt:'pro',notes:'',
 terms:LS.tu?LS.terms:'',tu:LS.tu||0,ty:(typeof PRESET!=='undefined'&&TY[PRESET]?PRESET:TY[LS.ty]?LS.ty:'gst-invoice'),xv:['','',''],adv:'',st:'',items:[{d:'',h:'',q:1,r:'',g:18}]};

const getp=k=>k.split('.').reduce((o,a)=>o[a],S);
const setp=(k,v)=>{const a=k.split('.');let o=S;while(a.length>1)o=o[a.shift()];o[a[0]]=v};
const sync=()=>$$('[data-k]').forEach(e=>{const v=getp(e.dataset.k);e.type==='checkbox'?e.checked=!!v:e.value=v??''});
function items(){const Y=TY[S.ty],ph=s=>`placeholder="${esc(s)}" aria-label="${esc(s)}"`;
 $('#items').innerHTML=S.items.map((i,n)=>`<div class="it" data-n="${n}"><input class="d" data-f="d" value="${esc(i.d)}" ${ph(t(Y.dl||'desc'))}><input class="g" data-f="h" value="${esc(i.h)}" ${ph(t('hsn'))}><input data-f="q" type="number" min="0" step="any" value="${esc(i.q)}" ${ph(t(Y.ql||'qty'))}><input class="pr" data-f="r" type="number" min="0" step="any" value="${esc(i.r)}" ${ph(t(Y.rl||'rate'))}><input class="g gp" data-f="g" type="number" min="0" step="any" list="gr" value="${esc(i.g)}" ${ph(t('gp'))}><button class="x" type="button" data-del aria-label="Remove">×</button></div>`).join('')}
function render(){
 const c=calc(),g=c.g,Y=TY[S.ty],np=!!Y.np,nt=!!Y.nt,b=S.biz,cl=S.cli,sy={INR:'₹',USD:'$',EUR:'€',GBP:'£'}[S.cur],
 f=p=>(p/100).toLocaleString(S.cur==='INR'?'en-IN':'en-US',{minimumFractionDigits:2,maximumFractionDigits:2}),m=p=>sy+'\u00a0'+f(p),
 nm=k=>(ST.find(x=>x.slice(0,2)===k)||'   ').slice(3),row=(k,v,x='')=>`<tr class="${x}"><td class="r">${k}</td><td class="r">${v}</td></tr>`,
 ti=(S.lang==='hi'&&Y.h)||Y.ttl,im=s=>/^data:image\//.test(s||''),adv=Math.min(P(S.adv),c.tot);
 $('#sheet').innerHTML=`${S.st?`<div class="stp">${esc(S.st)}</div>`:''}<div class="hd" data-b="hd"><div>${im(b.logo)?`<img class="lg" src="${esc(b.logo)}" alt="">`:''}<b style="font-size:15px">${esc(b.name)}</b><div class="mu">${br(b.addr)}${b.phone?'<br>'+esc(b.phone):''}${b.email?'<br>'+esc(b.email):''}${g&&b.gstin?'<br>GSTIN: '+esc(b.gstin):''}${g&&b.state?'<br>'+esc(nm(b.state))+' ('+esc(b.state)+')':''}</div></div>
<div class="r"><h3>${esc(ti)}</h3><div>${t('no')}: <b>${esc(S.no)}</b></div><div>${t('date')}: ${esc(fd(S.date))}</div>${Y.dt==='due'?`<div>${t('due')}: ${esc(fd(S.due))}</div>`:Y.dt==='valid'?`<div>${t('valid')}: ${esc(fd(S.valid))}</div>`:''}${(Y.x||[]).map((l,i)=>l&&S.xv[i]?`<div>${esc(l)}: ${esc(S.xv[i])}</div>`:'').join('')}</div></div>
<div data-b="bt" style="margin-bottom:14px"><div class="mu">${esc(Y.bl||t('bt'))}</div><b>${esc(cl.name)}</b><div>${br(cl.addr)}${g&&cl.gstin?'<br>GSTIN: '+esc(cl.gstin):''}${g&&S.pos?'<br>'+t('pos')+': '+esc(nm(S.pos))+' ('+esc(S.pos)+')':''}</div></div>
<table data-b="it"><thead><tr><th>#</th><th>${esc(t(Y.dl||'desc'))}</th>${g?`<th>${t('hsn')}</th>`:''}<th class="r">${esc(t(Y.ql||'qty'))}</th>${np?'':`<th class="r">${esc(t(Y.rl||'rate'))}</th>${g&&!nt?`<th class="r">${t('tb')}</th><th class="r">${t('gp')}</th>`:`<th class="r">${t('amt')}</th>`}`}</tr></thead><tbody>${c.L.map((l,n)=>`<tr><td>${n+1}</td><td>${br(l.d)||'&nbsp;'}</td>${g?`<td>${esc(l.h)}</td>`:''}<td class="r">${esc(l.q)}</td>${np?'':`<td class="r">${f(P(l.r))}</td>${g&&!nt?`<td class="r">${f(l.tb)}</td><td class="r">${l.rt}%</td>`:`<td class="r">${f(l.amt)}</td>`}`}</tr>`).join('')}</tbody></table>
${np?'':`<table class="tt" data-b="tt" style="width:270px;margin:12px 0 0 auto">${row(t('sub'),m(c.sub))}${c.disc?row(t('disc2'),'− '+m(c.disc)):''}${nt?'':g?row(t('tb'),m(c.tb))+(c.intra?row(t('cg'),m(c.cg))+row(t('sg'),m(c.sg)):row(t('ig'),m(c.ig))):c.tx?row(t('tx')+' ('+(parseFloat(S.tr)||0)+'%)',m(c.tx)):''}${c.ro?row(t('rof'),(c.ro<0?'− ':'')+m(Math.abs(c.ro))):''}${row(t('tot'),m(c.tot),'gt')}${adv?row(t('adv'),'− '+m(adv))+row(t('bal'),m(c.tot-adv),'gt'):''}</table>
<p data-b="wd" style="margin:12px 0"><span class="mu">${t('wd')}:</span> <b>${esc(words(c.tot,S.cur))}</b></p>`}
${b.bank||b.upi?`<div data-b="bank" style="margin-top:10px;display:flex;justify-content:space-between;gap:12px"><div><div class="mu">${t('bank')}</div>${br(b.bank)}${b.upi?'<br>UPI: '+esc(b.upi):''}</div>${b.upi&&S.cur==='INR'&&!np?qr(b.upi,b.name,c.tot-adv,S.no):''}</div>`:''}
${S.notes?`<div data-b="notes" style="margin-top:10px"><div class="mu">${t('notes')}</div>${br(S.notes)}</div>`:''}
${S.terms?`<div data-b="terms" style="margin-top:10px"><div class="mu">${t('terms')}</div>${br(S.terms)}</div>`:''}
<div class="r" data-b="sig" style="margin-top:36px">${t('for')} <b>${esc(b.name)}</b>${im(b.sig)?`<img src="${esc(b.sig)}" alt="" style="max-height:48px;max-width:180px;display:block;margin:4px 0 4px auto">`:'<div style="height:44px"></div>'}<span style="border-top:1px solid #111;padding-top:4px;display:inline-block;min-width:170px">${t('sig')}</span></div>`;
 ord();const ge=(id,v)=>$(id).textContent=v&&!gstOK(v)?t('gerr'):'';ge('#e1',b.gstin);ge('#e2',cl.gstin);
 $('#sup').textContent=g?t(b.state&&S.pos?(c.intra?'intra':'inter'):'pick'):'';
 const W=[];if(g){if(!/^[A-Za-z0-9\/-]{1,16}$/.test(S.no||''))W.push(t('wno'));
  S.items.forEach((i,k)=>{if(i.h&&!/^(\d{4}|\d{6}|\d{8})$/.test(i.h))W.push(t('wh')+' #'+(k+1));if(!nt&&i.g!==''&&![0,.25,3,5,12,18,28,40].includes(+i.g))W.push(t('wr')+' #'+(k+1))});
  if(b.gstin&&b.state&&b.gstin.slice(0,2)!==b.state)W.push(t('wst'));if(!np&&Y.gd&&c.tot>5e6)W.push(t('wew'))}
 $('#warn').innerHTML=W.map(esc).join('<br>');fit()}
function fit(){const w=$('#wrap'),s=$('#sheet');s.style.transform='none';const k=Math.min(1,w.clientWidth/s.offsetWidth);s.style.transform=`scale(${k})`;w.style.height=s.offsetHeight*k+'px'}
function lang(){document.documentElement.lang=S.lang;$$('[data-i]').forEach(e=>e.textContent=t(e.dataset.i));$('#lang').textContent=S.lang==='en'?'हिन्दी':'English';$('[data-i=bt]').textContent=TY[S.ty].bl||t('bt');slist();items();render()}
function tpl(){const Y=TY[S.ty],d=document.body.dataset;S.tpl=Y.fam==='gst'?'gst':'standard';S.nt=!!Y.nt;d.t=S.tpl;d.d=Y.dt;Y.nt?d.nt=1:delete d.nt;Y.np?d.np=1:delete d.np;
 if(!S.touchedNo)S.no=nextNo();if(!S.tu)S.terms=Y.tm||'';if(!S.stT)S.st=Y.st||'';
 $('#ty').value=S.ty;if(!window.NAV)document.title=Y.n+' Generator – DocoPDF';
 $('#xf').innerHTML=(Y.x||[]).map((l,i)=>l?`<label><span>${esc(l)}</span><input data-xi="${i}" value="${esc(S.xv[i]||'')}"></label>`:'').join('');
 $('[data-i=bt]').textContent=Y.bl||t('bt');sync();items();render()}
const pos=()=>{S.pos=S.cli.state;$('[data-k=pos]').value=S.pos};
$$('select.st').forEach(s=>s.innerHTML='<option value=""></option>'+ST.map(x=>`<option value="${x.slice(0,2)}">${esc(x)}</option>`).join(''));
document.addEventListener('input',e=>{const el=e.target,k=el.dataset.k;
 if(k){let v=el.type==='checkbox'?el.checked:el.value;
  if(/gstin$/.test(k)){v=v.toUpperCase().replace(/\s/g,'');el.value=v}
  setp(k,v);
  if(/gstin$/.test(k)&&ST.some(x=>x.slice(0,2)===v.slice(0,2))){const sk=k.replace('gstin','state');setp(sk,v.slice(0,2));$(`[data-k="${sk}"]`).value=v.slice(0,2);if(sk==='cli.state')pos()}
  if(k==='cli.state')pos();if(k==='no')S.touchedNo=1;if(k==='terms')S.tu=1;if(k==='st')S.stT=1;
  if(/^biz\./.test(k)||k==='terms'||k==='cur')save();
  render()}
 else if(el.dataset.xi!==undefined){S.xv[el.dataset.xi]=el.value;render()}else if(el.dataset.f){S.items[el.closest('.it').dataset.n][el.dataset.f]=el.value;render()}});
$('#items').onclick=e=>{if(e.target.dataset.del!==undefined&&S.items.length>1){S.items.splice(+e.target.closest('.it').dataset.n,1);items();render()}};
$('#add').onclick=()=>{S.items.push(blank());items();render();$$('#items .d').pop().focus()};

$('#lang').onclick=()=>{S.lang=S.lang==='en'?'hi':'en';save();lang()};
$('#lg').onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader;r.onload=()=>{const im=new Image;im.onload=()=>{const k=Math.min(1,300/im.width),cv=document.createElement('canvas');cv.width=im.width*k;cv.height=im.height*k;cv.getContext('2d').drawImage(im,0,0,cv.width,cv.height);S.biz.logo=cv.toDataURL('image/png');save();render()};im.src=r.result};r.readAsDataURL(f)};
$('#lx').onclick=()=>{S.biz.logo='';S.biz.sig='';$('#lg').value='';save();render()};
$('#new').onclick=()=>{Object.assign(S,{cli:{name:'',addr:'',gstin:'',state:''},pos:'',no:bump(S.no),touchedNo:1,xv:['','',''],adv:'',st:'',stT:0,date:today(),due:plus(15),valid:plus(15),d:'',tr:'',notes:'',items:[blank()]});tpl()};
let T0=document.title;
addEventListener('beforeprint',()=>{T0=document.title;document.title=S.no||'invoice'});addEventListener('afterprint',()=>document.title=T0);
$('#pr').onclick=()=>{S.dz=false;ord();(LS.l=LS.l||{})[S.ty]=S.no;save();print()};
$('#pdf').onclick=async()=>{S.dz=false;ord();(LS.l=LS.l||{})[S.ty]=S.no;save();const sh=$('#sheet');
 try{
  if(!window.html2pdf)await new Promise((ok,no)=>{const s=document.createElement('script');s.src='https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js';s.onload=ok;s.onerror=no;document.head.append(s)});
  sh.style.transform='none';sh.style.minHeight='290mm';
  await html2pdf().set({margin:0,filename:(S.no||'invoice')+'.pdf',image:{type:'jpeg',quality:.98},html2canvas:{scale:2},jsPDF:{unit:'mm',format:'a4'},pagebreak:{mode:['css','legacy'],avoid:'tr'}}).from(sh).save()
 }catch(e){print()}finally{sh.style.minHeight='';fit()}};
const KEYS=['hd','bt','it','tt','wd','bank','notes','terms','sig'];
S.ord=LS.ord&&LS.ord.length===KEYS.length?LS.ord:KEYS.slice();S.ac=LS.ac||'#0b6b4d';S.dz=false;
function ord(){const sh=$('#sheet');sh.style.setProperty('--ac',S.ac);S.ord.forEach(k=>{const e=sh.querySelector(`[data-b=${k}]`);e&&sh.append(e)});sh.classList.toggle('dz',S.dz);$$('#sheet [data-b]').forEach(e=>e.draggable=S.dz)}
function qr(id,name,tot,no){if(!window.qrcode)return'';try{const q=qrcode(0,'M');q.addData(`upi://pay?pa=${encodeURIComponent(id)}&pn=${encodeURIComponent(name||'')}&am=${(tot/100).toFixed(2)}&cu=INR&tn=${encodeURIComponent('Invoice '+no)}`);q.make();const n=q.getModuleCount();let p='';for(let r=0;r<n;r++)for(let c=0;c<n;c++)if(q.isDark(r,c))p+=`M${c} ${r}h1v1h-1z`;return`<svg viewBox="-2 -2 ${n+4} ${n+4}" width="96" height="96" shape-rendering="crispEdges" role="img" aria-label="UPI QR"><path d="${p}"/></svg>`}catch(e){return''}}
let dk=null;const SH=$('#sheet');
SH.addEventListener('dragstart',e=>{const b=e.target.closest('[data-b]');if(b){dk=b.dataset.b;e.dataTransfer.setData('text/plain',dk)}});
SH.addEventListener('dragover',e=>{if(dk)e.preventDefault()});
SH.addEventListener('drop',e=>{e.preventDefault();const b=e.target.closest('[data-b]');if(!dk||!b||b.dataset.b===dk)return;const r=b.getBoundingClientRect(),o=S.ord.filter(k=>k!==dk);o.splice(o.indexOf(b.dataset.b)+(e.clientY>r.top+r.height/2?1:0),0,dk);S.ord=o;dk=null;save();render()});
$('#dz').onclick=()=>{S.dz=!S.dz;$('#dz').setAttribute('aria-pressed',S.dz);ord()};
$('#ac').value=S.ac;$('#ac').oninput=e=>{S.ac=e.target.value;save();ord()};
const fy=d=>{const y=+d.slice(0,4),m=+d.slice(5,7),s=m>=4?y:y-1;return String(s).slice(2)+'-'+String(s+1).slice(2)};
const nextNo=()=>{const Y=TY[S.ty],l=(LS.l||{})[S.ty];return l?bump(l):Y.pf+(Y.fam==='gst'?'/'+fy(S.date)+'/':'-')+'001'};
$('#ty').innerHTML=GR.map(([g,ks])=>`<optgroup label="${esc(g)}">${ks.map(k=>`<option value="${k}">${esc(TY[k].n)}</option>`).join('')}</optgroup>`).join('');
$('#ty').onchange=e=>{if(window.NAV)location.href=window.NAV+e.target.value+'/';else{S.ty=e.target.value;tpl()}};
const sl=()=>{try{return JSON.parse(localStorage.getItem('dp_inv_saved')||'[]')}catch(e){return[]}};
function slist(){$('#sv').innerHTML=`<option value="">${t('open')}</option>`+sl().map((x,i)=>`<option value="${i}">${esc(x.no)} · ${esc(x.cli.name||'')}</option>`).join('')}
$('#svb').onclick=()=>{const{biz,...o}=S,a=sl().filter(x=>!(x.no===S.no&&x.ty===S.ty));a.unshift(JSON.parse(JSON.stringify(o)));try{localStorage.setItem('dp_inv_saved',JSON.stringify(a.slice(0,50)))}catch(e){}slist()};
$('#sv').onchange=e=>{const x=sl()[e.target.value];if(!x)return;Object.assign(S,x,{biz:S.biz,lang:S.lang,ord:S.ord,ac:S.ac,dz:false,touchedNo:1});sync();tpl();slist()};
$('#sg').onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader;r.onload=()=>{const im=new Image;im.onload=()=>{const k=Math.min(1,300/im.width),cv=document.createElement('canvas');cv.width=im.width*k;cv.height=im.height*k;cv.getContext('2d').drawImage(im,0,0,cv.width,cv.height);S.biz.sig=cv.toDataURL('image/png');save();render()};im.src=r.result};r.readAsDataURL(f)};
addEventListener('resize',fit);
sync();lang();tpl();
